package ir.modares.autologin

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

object SecurePrefs {
    private const val PREFS = "settings"
    private const val KEY_ALIAS = "modares_autologin_aes"
    private const val USER = "username_enc"
    private const val PASS = "password_enc"
    private const val SSIDS = "ssids"
    private const val ENABLED = "enabled"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun secretKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            ).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
             .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
             .setRandomizedEncryptionRequired(true)
             .build()
        )
        return generator.generateKey()
    }

    private fun encrypt(value: String): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, secretKey())
        val encrypted = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(cipher.iv + encrypted, Base64.NO_WRAP)
    }

    private fun decrypt(value: String?): String {
        if (value.isNullOrEmpty()) return ""
        return try {
            val bytes = Base64.decode(value, Base64.NO_WRAP)
            val iv = bytes.copyOfRange(0, 12)
            val data = bytes.copyOfRange(12, bytes.size)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, iv))
            String(cipher.doFinal(data), Charsets.UTF_8)
        } catch (_: Exception) { "" }
    }

    fun saveCredentials(ctx: Context, username: String, password: String) {
        prefs(ctx).edit().putString(USER, encrypt(username))
            .putString(PASS, encrypt(password)).apply()
    }
    fun username(ctx: Context) = decrypt(prefs(ctx).getString(USER, null))
    fun password(ctx: Context) = decrypt(prefs(ctx).getString(PASS, null))
    fun ssids(ctx: Context): MutableSet<String> =
        prefs(ctx).getStringSet(SSIDS, emptySet())?.toMutableSet() ?: mutableSetOf()
    fun saveSsids(ctx: Context, values: Set<String>) {
        prefs(ctx).edit().putStringSet(SSIDS, values.toSet()).apply()
    }
    fun enabled(ctx: Context) = prefs(ctx).getBoolean(ENABLED, false)
    fun setEnabled(ctx: Context, enabled: Boolean) {
        prefs(ctx).edit().putBoolean(ENABLED, enabled).apply()
    }
}
