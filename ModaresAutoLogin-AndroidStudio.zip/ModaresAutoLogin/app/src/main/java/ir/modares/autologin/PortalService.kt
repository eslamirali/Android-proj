package ir.modares.autologin

import android.app.*
import android.content.Context
import android.content.Intent
import android.net.*
import android.net.wifi.WifiManager
import android.os.*
import android.content.pm.ServiceInfo
import javax.net.ssl.HttpsURLConnection
import java.net.URLEncoder
import java.net.URL
import java.net.CookieManager
import java.net.CookiePolicy
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.Executors
import java.util.regex.Pattern

class PortalService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private var callback: ConnectivityManager.NetworkCallback? = null
    private var busy = false
    private var lastSsid: String? = null
    private val channelId = "portal_monitor"
    private val portal = "https://acc.modares.ac.ir:8090/"
    private val keepAlive = object : Runnable {
        override fun run() {
            if (SecurePrefs.enabled(this@PortalService)) {
                executor.execute { maintainSession() }
                handler.postDelayed(this, 180_000L)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        CookieHandlerHolder.install()
        createChannel()
        val notification = notification("در انتظار اتصال به شبکه مجاز")
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(7, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else startForeground(7, notification)
        registerNetworkCallback()
        handler.postDelayed(keepAlive, 180_000L)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!SecurePrefs.enabled(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        executor.execute { checkAndLogin() }
        return START_STICKY
    }

    private fun registerNetworkCallback() {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val req = NetworkRequest.Builder().addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build()
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                handler.postDelayed({ executor.execute { checkAndLogin() } }, 2000L)
            }
            override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
                if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                    handler.postDelayed({ executor.execute { checkAndLogin() } }, 2000L)
                }
            }
            override fun onLost(network: Network) {
                updateNotification("اتصال Wi-Fi قطع شد")
                lastSsid = null
            }
        }
        callback = cb
        cm.registerNetworkCallback(req, cb)
    }

    @Suppress("DEPRECATION")
    private fun currentSsid(): String? {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return null
        val caps = cm.getNetworkCapabilities(network) ?: return null
        if (!caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return null
        val wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        return wifi.connectionInfo?.ssid?.removeSurrounding("\"", "\"")?.takeIf {
            it.isNotBlank() && it != "<unknown ssid>"
        }
    }

    private fun checkAndLogin() {
        if (busy) return
        val ssid = currentSsid() ?: run { updateNotification("در انتظار Wi-Fi"); return }
        val allowed = SecurePrefs.ssids(this).any { it.equals(ssid, ignoreCase = true) }
        if (!allowed) { updateNotification("شبکه خارج از فهرست مجاز: $ssid"); return }
        if (lastSsid == ssid) {
            // Existing session may still be alive; periodic keepalive checks it.
            updateNotification("متصل به $ssid")
            return
        }
        lastSsid = ssid
        login()
    }

    private fun login() {
        if (busy) return
        busy = true
        try {
            val user = SecurePrefs.username(this)
            val pass = SecurePrefs.password(this)
            if (user.isBlank() || pass.isBlank()) {
                updateNotification("اطلاعات ورود تنظیم نشده")
                return
            }
            updateNotification("در حال ورود به پورتال…")
            val body = "mode=191&username=${enc(user.replace("'", "''"))}" +
                "&password=${enc(pass)}&a=${System.currentTimeMillis()}&producttype=2"
            val response = request("login.xml", "POST", body)
            val status = xmlValue(response, "status")
            val message = xmlValue(response, "message")
            if (status == "LIVE") updateNotification("ورود موفق؛ اتصال فعال است")
            else {
                updateNotification("ورود ناموفق: ${message.ifBlank { status.ifBlank { "پاسخ نامعتبر" } }}")
                lastSsid = null
            }
        } catch (e: Exception) {
            updateNotification("خطای اتصال: ${e.javaClass.simpleName}")
            lastSsid = null
        } finally { busy = false }
    }

    private fun maintainSession() {
        if (busy) return
        val ssid = currentSsid() ?: return
        if (!SecurePrefs.ssids(this).any { it.equals(ssid, true) }) return
        busy = true
        var retryLogin = false
        try {
            val user = SecurePrefs.username(this)
            if (user.isBlank()) return
            val path = "live?mode=192&username=${enc(user)}&a=${System.currentTimeMillis()}&producttype=2"
            val response = request(path, "GET", null)
            val ack = xmlValue(response, "ack")
            val status = xmlValue(response, "status")
            when {
                ack.equals("ack", true) -> updateNotification("اتصال فعال است")
                ack.equals("nack", true) || status == "LOGIN" ||
                    response.contains("login_again", true) -> {
                    lastSsid = null
                    retryLogin = true
                    updateNotification("نشست منقضی شده؛ ورود مجدد…")
                }
                response.contains("live_off", true) -> updateNotification("اتصال فعال؛ Keepalive غیرفعال")
                else -> updateNotification("پاسخ Keepalive نامشخص")
            }
        } catch (_: Exception) {
            lastSsid = null
            updateNotification("بررسی اتصال ناموفق؛ تلاش مجدد در نوبت بعد")
        } finally { busy = false }
        if (retryLogin) login()
    }

    private fun request(path: String, method: String, body: String?): String {
        val conn = (URL(portal + path).openConnection() as HttpsURLConnection)
        conn.requestMethod = method
        conn.connectTimeout = 12000
        conn.readTimeout = 15000
        conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
        conn.setRequestProperty("Referer", portal + "httpclient.html")
        if (body != null) {
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        }
        val stream = if (conn.responseCode in 200..399) conn.inputStream else conn.errorStream
        val result = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        conn.disconnect()
        return result
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private fun xmlValue(xml: String, tag: String): String {
        val p = Pattern.compile("<$tag>\\s*(?:<!\\[CDATA\\[)?(.*?)(?:]]>)?\\s*</$tag>", Pattern.DOTALL)
        return p.matcher(xml).let { if (it.find()) it.group(1).trim() else "" }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(channelId, "پایش ورود دانشگاه", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }
    private fun notification(text: String): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, channelId)
            .setContentTitle("Modares Auto Login")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_notify_sync_noanim)
            .setOngoing(true)
            .setContentIntent(open)
            .build()
    }
    private fun updateNotification(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(7, notification(text))
    }

    override fun onDestroy() {
        handler.removeCallbacks(keepAlive)
        callback?.let {
            (getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager).unregisterNetworkCallback(it)
        }
        executor.shutdownNow()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?) = null

    private object CookieHandlerHolder {
        fun install() {
            if (java.net.CookieHandler.getDefault() == null) {
                java.net.CookieHandler.setDefault(CookieManager(null, CookiePolicy.ACCEPT_ALL))
            }
        }
    }
}
