package ir.modares.autologin

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import android.graphics.Typeface

class MainActivity : Activity() {
    private lateinit var username: EditText
    private lateinit var password: EditText
    private lateinit var ssidInput: EditText
    private lateinit var ssidList: LinearLayout
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
        username.setText(SecurePrefs.username(this))
        renderSsids()
        status.text = if (SecurePrefs.enabled(this)) "پایش فعال است" else "پایش غیرفعال است"
    }

    private fun render() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(0xFFF4F5F8.toInt())
        }
        val title = TextView(this).apply {
            text = "ورود خودکار مودارس"
            textSize = 24f
            setTypeface(null, Typeface.BOLD)
            setTextColor(0xFF172033.toInt())
            gravity = Gravity.CENTER
        }
        root.addView(title, matchWrap())
        root.addView(label("اطلاعات حساب"))
        username = EditText(this).apply { hint = "نام کاربری"; singleLine = true }
        password = EditText(this).apply {
            hint = "رمز عبور"; singleLine = true
            inputType = 129
        }
        root.addView(username, matchWrap())
        root.addView(password, matchWrap())

        root.addView(label("شبکه‌های Wi-Fi مجاز"))
        ssidInput = EditText(this).apply { hint = "نام دقیق SSID"; singleLine = true }
        root.addView(ssidInput, matchWrap())
        val add = Button(this).apply {
            text = "افزودن شبکه"
            setOnClickListener {
                val s = ssidInput.text.toString().trim().removeSurrounding("\"", "\"")
                if (s.isNotBlank()) {
                    val all = SecurePrefs.ssids(this@MainActivity)
                    all.add(s)
                    SecurePrefs.saveSsids(this@MainActivity, all)
                    ssidInput.text.clear()
                    renderSsids()
                }
            }
        }
        root.addView(add, matchWrap())
        ssidList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ssidList, matchWrap())

        val save = Button(this).apply {
            text = "ذخیره اطلاعات"
            setOnClickListener {
                val u = username.text.toString().trim()
                val p = password.text.toString()
                if (u.isBlank() || p.isBlank()) {
                    toast("نام کاربری و رمز عبور را وارد کن")
                } else {
                    SecurePrefs.saveCredentials(this@MainActivity, u, p)
                    toast("اطلاعات به‌صورت رمزنگاری‌شده ذخیره شد")
                }
            }
        }
        root.addView(save, matchWrap())

        val toggle = Button(this).apply {
            text = "فعال‌سازی ورود خودکار"
            setOnClickListener { toggleService() }
        }
        root.addView(toggle, matchWrap())

        status = TextView(this).apply {
            textSize = 14f
            setTextColor(0xFF344054.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 0)
        }
        root.addView(status, matchWrap())
        val note = TextView(this).apply {
            text = "برای شناسایی SSID در اندروید، مجوز مکان و روشن بودن Location ممکن است لازم باشد."
            textSize = 12f
            setTextColor(0xFF667085.toInt())
            setPadding(0, 12, 0, 0)
        }
        root.addView(note, matchWrap())
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
    }

    private fun label(s: String) = TextView(this).apply {
        text = s; textSize = 16f; setTypeface(null, Typeface.BOLD)
        setTextColor(0xFF172033.toInt()); setPadding(0, 22, 0, 6)
    }

    private fun renderSsids() {
        ssidList.removeAllViews()
        SecurePrefs.ssids(this).sorted().forEach { s ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            row.addView(TextView(this).apply {
                text = s; textSize = 14f; setTextColor(0xFF172033.toInt())
            }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(Button(this).apply {
                text = "حذف"
                setOnClickListener {
                    val all = SecurePrefs.ssids(this@MainActivity)
                    all.remove(s); SecurePrefs.saveSsids(this@MainActivity, all)
                    renderSsids()
                }
            })
            ssidList.addView(row)
        }
    }

    private fun toggleService() {
        if (username.text.isNullOrBlank() || password.text.isNullOrBlank()) {
            toast("ابتدا نام کاربری و رمز را وارد و ذخیره کن"); return
        }
        if (SecurePrefs.ssids(this).isEmpty()) {
            toast("حداقل یک SSID اضافه کن"); return
        }
        SecurePrefs.saveCredentials(this, username.text.toString().trim(), password.text.toString())
        if (Build.VERSION.SDK_INT >= 23 &&
            checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 41)
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 42)
            return
        }
        val enabled = !SecurePrefs.enabled(this)
        SecurePrefs.setEnabled(this, enabled)
        if (enabled) {
            val i = Intent(this, PortalService::class.java)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            status.text = "پایش فعال است"
        } else {
            stopService(Intent(this, PortalService::class.java))
            status.text = "پایش غیرفعال است"
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
            toggleService()
        } else toast("برای اجرای قابلیت ورود خودکار، مجوز لازم است")
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 6 }
}
